FactoryGirl.define do
  factory :product do
    name "MyString"
sku "MyString"
wholesale_price 1.5
description "MyText"
quantity 1
  end

end
