require_relative '../lib/calculator.rb'

describe Calculator do
	describe ".multiply" do
		
	end
end