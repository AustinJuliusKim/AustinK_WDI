angular
  .module('dictionaryApp',[]);
